package com.example.android.stage_one;

/**
 * Created by Ahmad_Mostafa on 12/2/2016.
 */
public interface MySubInterface
{
    void send_id(movie d);

}
