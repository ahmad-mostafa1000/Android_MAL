package com.example.android.stage_one;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by Ahmad_Mostafa on 11/5/2016.
 */


class Trailerholder
{
    TextView trailer;
TextView num;
}
public class MyBaseAdapterTrailer extends BaseAdapter
{
    Context con;
    Activity context1;
    LayoutInflater inflater;
GridView gridView;
    ArrayList<Trailer> data1=new ArrayList<>();

    public MyBaseAdapterTrailer(Activity context,ArrayList<Trailer>data)
    {
        context1=context; //?????????
        if(data!=null)
        {
            this.data1 = data;
        }

    }

    // gives you the Total Elements present in your adapter
    //  @Override
    public int getCount()
    {
        return data1.size();
    }
    //tells which item was clicked simply return here the way I did specifying the position .
// It actually return the whole view that you clicked with all its properties
// and thats why we just return here the view of the position we clicked in order to tell the BASEADAPTER Class that this view is cliked
    @Override
    public Object getItem(int position)
    {

        return data1.get(position);
    }

    @Override
    public long getItemId(int position)
    {
        return position ;
// retuning my Primary id from the arraylist by
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent)
    {
        //**parent**    the parent that this view will eventually be attached to

        View rowView = convertView;
        Trailerholder holder=null;


        if (convertView == null)   //always required to be checked as mentioned in google docs
        // this line checks for if initially row View is null then we have to create the Row View. Once it will be created then it will always Surpass this check and we will keep on reusing this rowView (thats what actually we are looking for)
        {

            inflater = (LayoutInflater)context1.getSystemService(Context.LAYOUT_INFLATER_SERVICE); //data on XML is inside my java object
            rowView = inflater.inflate(R.layout.trailer,parent, false); //choosing view to inflate from
            holder=new Trailerholder();



            holder.trailer= (TextView)rowView.findViewById(R.id.trailer11);
            holder.num= (TextView)rowView.findViewById(R.id.trailer_number);

            rowView.setTag(holder);

        }
        else
        {
            holder = (Trailerholder) rowView.getTag();
        }

       final Trailer temp=(Trailer) data1.get(position);
        holder.trailer.setText("Trailer");
        holder.num.setText(String.valueOf((temp.number)));

        return rowView;
    }


}
