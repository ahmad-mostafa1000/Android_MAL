package com.example.android.stage_one;

/**
 * Created by Ahmad_Mostafa on 11/5/2016.
 */
public class Review
{
    String Author;
    String content;
    Review( String Author,String content)
    {
        this.Author=Author;
        this.content=content;
    }
}
