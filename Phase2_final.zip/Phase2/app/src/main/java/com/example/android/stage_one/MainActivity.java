package com.example.android.stage_one;

import android.app.Activity;
import android.app.FragmentManager;
import android.content.SharedPreferences;
import android.os.Parcelable;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.graphics.Movie;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.format.Time;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements MyMainInterface
{


   movie test5;
    Activity activity;
    boolean check=false;


    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */

   /* public static boolean isNetworkAvailable(Context context)
    {
        ConnectivityManager connectivity = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);

        if (connectivity == null) {
            return false;
        } else {
            NetworkInfo[] info = connectivity.getAllNetworkInfo();
            if (info != null) {
                for (int i = 0; i < info.length; i++) {
                    if (info[i].getState() == NetworkInfo.State.CONNECTED) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
*/

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

  /*  check=isNetworkAvailable(context1);
        if(check==true)
       {
            new MyAsyncMain(0, gridView, context1, MainActivity.this).execute();
       }
       else
      {
            Toast.makeText(getApplicationContext(),"Error in Connection",Toast.LENGTH_SHORT).show();
        }

*/

/////////////////////////////////////////// Fragment /////////////////////////////////////////////////////////////////
      //fragmentManager start a transaction
     //   Create a new instance of your fragment
       // Add that fragment to your FragmentManager
        //add fragment to Main XML layout
        MainFragment fragment = new MainFragment();
        fragment.setListener(this);
        getSupportFragmentManager().beginTransaction().add(R.id.main_layout, fragment, "MainFragment").commit();
if(findViewById(R.id.sub_activity)!=null) //Tablet
{
    check=true;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    }

    @Override
    protected void onResume()
    {
        super.onResume();
    }



    @Override
    public void open_details(movie mymovie)
    {
        test5=mymovie;
        if(!check)//not Tablet
        {
        Intent myIntent = new Intent(MainActivity.this, SubActivity.class);
        myIntent.putExtra("key", (Parcelable) mymovie);
        startActivity(myIntent);
        }
    else //Tablet
        {

            SubFragment fragment1 = new SubFragment();
            Bundle extras = new Bundle();
            extras.putParcelable("key",mymovie);

            fragment1.setArguments(extras); //send bundle to fragment
            getSupportFragmentManager().beginTransaction().replace(R.id.sub_activity,fragment1,"").commit();//inflate details fragment
        }

    }






}

/////////////////////////////////////////////////////



    ///////////////////////////////////////////////////////////////////////////////
