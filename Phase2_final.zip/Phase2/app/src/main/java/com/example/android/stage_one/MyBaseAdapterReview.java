package com.example.android.stage_one;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

/**
 * Created by Ahmad_Mostafa on 11/5/2016.
 */


class Reviewholder
{
    TextView author;
    TextView content;
}


public class MyBaseAdapterReview extends BaseAdapter
{
    Activity context1;
    LayoutInflater inflater;

    ArrayList<Review> data1=new ArrayList<>();//=new ArrayList<>();

    public MyBaseAdapterReview(Activity context,ArrayList<Review>data)
    {
        context1=context; //?????????
        if(data!=null)
        {
            this.data1 = data;
        }

    }

    // gives you the Total Elements present in your adapter
    //  @Override
    public int getCount()
    {
        return data1.size();
    }

    @Override
    public Object getItem(int position)
    {

        return data1.get(position);
    }

    @Override
    public long getItemId(int position)
    {
        return position ;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent)
    {

        View rowView = convertView;
        Reviewholder holder=null;


        if (convertView == null)   //always required to be checked as mentioned in google docs
        // this line checks for if initially row View is null then we have to create the Row View. Once it will be created then it will always Surpass this check and we will keep on reusing this rowView (thats what actually we are looking for)
        {
            // if it's not recycled, initialize some attributes
            //??????????????????????????????????????????/
            inflater = (LayoutInflater)context1.getSystemService(Context.LAYOUT_INFLATER_SERVICE); //data on XML is inside my java object
            rowView = inflater.inflate(R.layout.reviewshape,parent, false); //choosing view to inflate from
            holder=new Reviewholder();


            holder.author= (TextView) rowView.findViewById(R.id.author);
            holder.content= (TextView)rowView.findViewById(R.id.content);

            rowView.setTag(holder); //save holde tag in the view

        }
        else
        {
            holder = (Reviewholder) rowView.getTag();
        }

        Review temp=(Review) data1.get(position);



       holder.author.setText(temp.Author);
         holder.content.setText(temp.content);

        return rowView;
    }
}
