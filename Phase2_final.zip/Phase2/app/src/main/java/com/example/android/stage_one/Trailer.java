package com.example.android.stage_one;

import android.widget.TextView;

/**
 * Created by Ahmad_Mostafa on 11/6/2016.
 */
public class Trailer
{
    String key;
   int number;
    Trailer(String v,int y)
    {
        key=v;
        number=y;
    }
}
