package com.example.android.stage_one;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.GridView;

import java.util.ArrayList;

public class Reviews extends AppCompatActivity
{
    GridView gridView;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reviews);

        gridView = (GridView) findViewById(R.id.review_grid);

        Intent intentt = getIntent();
        String id = (String) intentt.getExtras().getSerializable("key1");

         new MyAsyncReview(id, Reviews.this).execute();
    }

    void GetReview(ArrayList<Review> temp)
    {
       gridView.setAdapter(new MyBaseAdapterReview(Reviews.this,temp));

    }



}
