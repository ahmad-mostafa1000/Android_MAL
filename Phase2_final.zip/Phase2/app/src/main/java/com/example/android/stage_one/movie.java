package com.example.android.stage_one;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

/**
 * Created by Ahmad_Mostafa on 10/18/2016.
 */

class movie implements Parcelable {
        String title;
        String discription;
        String image;
        String rate;
        String release;
        String id; //for trailers and reviews URL

        movie( String title,String disc,String image1,String rate1,String release, String id)
        {
        this.title=title;
        this.discription=disc;
        this.image=image1;//.substring(1);
        this.rate=rate1;
        this.release=release;
        this.id=id;
        }

protected movie(Parcel in) {
        title = in.readString();
        discription = in.readString();
        image = in.readString();
        rate = in.readString();
        release = in.readString();
        id = in.readString();
        }

@Override
public int describeContents() {
        return 0;
        }

@Override
public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(title);
        dest.writeString(discription);
        dest.writeString(image);
        dest.writeString(rate);
        dest.writeString(release);
        dest.writeString(id);
        }

@SuppressWarnings("unused")
public static final Parcelable.Creator<movie> CREATOR = new Parcelable.Creator<movie>() {
@Override
public movie createFromParcel(Parcel in) {
        return new movie(in);
        }

@Override
public movie[] newArray(int size) {
        return new movie[size];
        }
        };
        }
