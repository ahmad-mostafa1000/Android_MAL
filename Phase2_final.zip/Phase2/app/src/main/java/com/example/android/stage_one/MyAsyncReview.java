package com.example.android.stage_one;

import android.app.Activity;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by Ahmad_Mostafa on 11/5/2016.
 */




public class MyAsyncReview extends AsyncTask<Void, Void, ArrayList<Review>>
{

    String URL_Request="";
    String ID="";
Activity activity;

    MyAsyncReview(String id,Activity a)
    {
        ID=id;
        activity=a;
    }

    @Override
    protected ArrayList<Review> doInBackground(Void... voids)//void array
    {
        // These two need to be declared outside the try/catch
// so that they can be closed in the finally block.
        HttpURLConnection urlConnection = null;
        BufferedReader reader = null;

// Will contain the raw JSON response as a string.
        String movie_info_string = null;

        try {


                URL_Request="http://api.themoviedb.org/3/movie/"+ID+"/reviews?api_key=d9489eb3f43cfe34e1fd72d6fb528d96";



            URL url = new URL(URL_Request);
            // Create the request to OpenWeatherMap, and open the connection

            urlConnection = (HttpURLConnection) url.openConnection(); ///????????????????????????????//
            urlConnection.setRequestMethod("GET");
            urlConnection.connect();

            // Read the input stream into a String
            InputStream inputStream = urlConnection.getInputStream();//DATA COME IN SHAPE OF INPUT STREAM

            StringBuffer buffer = new StringBuffer(); //STRING THAT WE CAN APPEND ON IT WITHOUT OVERRIDING PAST DATA
            if (inputStream == null) //case nothing read from URL
            {
                // Nothing to do.
                movie_info_string = null;
            }
            reader = new BufferedReader(new InputStreamReader(inputStream)); //READING LINE BY LINE

            String line;
            while ((line = reader.readLine()) != null) {
                // Since it's JSON, adding a newline isn't necessary (it won't affect parsing)
                // But it does make debugging a *lot* easier if you print out the completed
                // buffer for debugging.
                buffer.append(line + "\n"); //APPENDING IN THE BUFFER
            }

            if (buffer.length() == 0) //NOTHING READ
            {
                // Stream was empty.  No point in parsing.
                movie_info_string = null;
            }
            movie_info_string = buffer.toString();

        }

        catch (IOException e)  //CASE THE CODE DIDN'T GET DATA SUCCESSFULLY
        {
            //  Toast.makeText(context, "HTTP Connection Error : " + e.toString(), Toast.LENGTH_LONG).show();
            return null;

        }

        finally //CLOSE URL CONNECTION
        {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (reader != null) {
                try {
                    reader.close();
                } catch (final IOException e)
                {

                }
            }
        }
        //NOW I HAVE THE DATA IN movie_info_string
///////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////
        // These are the names of the JSON objects that need to be extracted.
        final String author = "author";
        final String content = "content";

        ArrayList<Review> temp = new ArrayList<>();  //array to store parsed data

        try {
            JSONObject json_object = new JSONObject(movie_info_string);

            JSONArray json_array = json_object.getJSONArray("results"); //json array is a json object named json_object


            for (int i = 0; i < json_array.length(); i++)
            {
                JSONObject obj = json_array.getJSONObject(i);//objects inside this array between {}
                Review rev = new Review(obj.getString(author), obj.getString(content));
                temp.add(rev);
            }
        }

        catch (JSONException e)
        {
        }

        return temp;

    }

    @Override
    protected void onPostExecute(ArrayList<Review> temp1)
    {


    ((Reviews)activity).GetReview(temp1);

    }


}
