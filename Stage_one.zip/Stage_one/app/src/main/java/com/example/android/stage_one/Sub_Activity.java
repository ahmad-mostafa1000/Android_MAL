package com.example.android.stage_one;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;


public class Sub_Activity extends AppCompatActivity {

   Context context1;
 //   View item;

    // Populate the data into the template view using the data object
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_);
///////////////////////////////////////////////////////////////////////////////////////


        ImageView picture3 = (ImageView)findViewById(R.id.pic1);
        TextView disc3 = (TextView) findViewById(R.id.disc1);
        TextView release3 = (TextView) findViewById(R.id.release1);
        TextView rate3=(TextView) findViewById(R.id.rate1);
        TextView title3=(TextView) findViewById(R.id.title1);

        Intent intent1 = getIntent();

     movie test5=(movie)intent1.getExtras().getSerializable("key");


     release3.setText(String.valueOf("Release: "+test5.release));
      disc3.setText("Descripstion: "+test5.discription.toString());
        Picasso.with(context1).load(test5.image).into(picture3);
        rate3.setText("Rate: "+String.valueOf(test5.rate));
       title3.setText(test5.title.toString());

      // http://api.themoviedb.org/3/movie/movie/{id}/reviews?api_key=d9489eb3f43cfe34e1fd72d6fb528d96
    }



}
