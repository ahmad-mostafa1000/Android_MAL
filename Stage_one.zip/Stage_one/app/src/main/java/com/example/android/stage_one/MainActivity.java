package com.example.android.stage_one;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.format.Time;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.appindexing.Action;
import com.google.android.gms.appindexing.AppIndex;
import com.google.android.gms.common.api.GoogleApiClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity
{

    GridView gridView;
    ArrayList<movie> test1;
    Activity activity;
    Context context1;

    private Spinner spinner;

    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        gridView = (GridView) findViewById(R.id.gridView);


        new My_Async(0,gridView,context1,MainActivity.this).execute();

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int position, long arg3) {
                //   movie travel;
                //        travel=test1.get(position);

                Intent myIntent = new Intent(MainActivity.this, Sub_Activity.class);
                myIntent.putExtra("key", (Serializable) test1.get(position));
                startActivity(myIntent);

            }
        });
///////////////////////////////////////////SETTINGS(SPINNER)/////////////////////////////////////////////////////////////////
        ArrayList<String> aOptions = new ArrayList<String>();
        aOptions.add("Sort by rate");
        aOptions.add("Sort by popularity");

        ArrayAdapter<String> adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, aOptions);
        Spinner spinner = (Spinner) findViewById(R.id.movie_spinner);
        spinner.setAdapter(adapter);


////////////////////////////////////////////////////////////////////////////////////////////////////////////

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                String selectedItem = parent.getItemAtPosition(pos).toString();

                if (pos == 0)
                {
                    new My_Async(1,gridView,context1,MainActivity.this).execute();
                }
                else if (pos == 1)
                {
                    new My_Async(2,gridView,context1,MainActivity.this).execute();
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


    @Override
    protected void onResume()
    {
        super.onResume();
    }
    public void updateUi( ArrayList<movie> test)
    {
        gridView.setAdapter(new Base_adapter(MainActivity.this, test));//pass new data to the adapter/
        test1=new ArrayList<>();
        test1.addAll(test);

    }
}
/////////////////////////////////////////////////////



    ///////////////////////////////////////////////////////////////////////////////
