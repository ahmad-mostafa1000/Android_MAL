package com.example.android.stage_one;

import java.io.Serializable;

/**
 * Created by Ahmad_Mostafa on 10/18/2016.
 */

class movie implements Serializable
{
    String title;
    String discription;
  String image;
    String rate;
     String release;
    String id;

    movie( String title,String disc,String image1,String rate1,String release)//, String id)
    {
        this.title=title;
         this.discription=disc;
        this.image="https://image.tmdb.org/t/p/w500/"+image1.substring(1);
        this.rate=rate1;
        this.release=release;
       // this.id=id;
    }
}
